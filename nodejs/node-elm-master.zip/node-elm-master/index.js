require('babel-core/register');
require('./app.js');